package com.cst3104.Luka;
import com.cst3104.Luka.R;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.cst3104.Luka.databinding.ActivityChatRoomBinding;
import com.cst3104.Luka.databinding.SentMessageBinding;
import com.cst3104.Luka.databinding.ReceivedMessageBinding;
import com.google.android.material.snackbar.Snackbar;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;


public class ChatRoom extends AppCompatActivity {


    ActivityChatRoomBinding binding;
    ArrayList<ChatMessage> messages = new ArrayList<>();
    ChatRoomViewModel chatModel;
    RecyclerView.Adapter<MyRowHolder> myAdapter;
    ChatMessageDAO mDAO;

    @Override public boolean onOptionsItemSelected(@NonNull MenuItem item){

        switch(item.getItemId()){
            case R.id.item_1:
                int position = messages.size() -1;
                AlertDialog.Builder alertMsg = new AlertDialog.Builder(ChatRoom.this);
                alertMsg.setTitle(getString(R.string.delete_message));
                alertMsg.setMessage(getString(R.string.select_row) + position);

                alertMsg.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (position >= 0 && position < messages.size()) {
                            messages.remove(position);
                            //theAdapter.notifyDataSetChanged();
                        }
                    }
                });

                alertMsg.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                alertMsg.create().show();

        }
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityChatRoomBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.myToolbar);



        chatModel = new ViewModelProvider(this).get(ChatRoomViewModel.class);
        messages = chatModel.messages.getValue();

        MessageDatabase db = Room.databaseBuilder(getApplicationContext(),MessageDatabase.class, "Chat-database").build();
        mDAO = db.cmDAO();

        if (messages == null) {
            chatModel.messages.postValue(messages = new ArrayList<ChatMessage>());
        }
        binding.recycleView.setLayoutManager(new LinearLayoutManager(this));


        binding.recycleView.setAdapter(myAdapter = new RecyclerView.Adapter<MyRowHolder>() {
            @NonNull
            @Override
            public MyRowHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                if (viewType == 0) {
                    SentMessageBinding sentBinding = SentMessageBinding.inflate(getLayoutInflater(), parent, false);
                    return new MyRowHolder(sentBinding.getRoot());
                } else {
                    ReceivedMessageBinding receivedBinding = ReceivedMessageBinding.inflate(getLayoutInflater(), parent, false);
                    return new MyRowHolder(receivedBinding.getRoot());
                }
            }


            @Override
            public void onBindViewHolder(@NonNull MyRowHolder holder, int position) {
                ChatMessage chatMessage = messages.get(position);
                holder.messageText.setText(chatMessage.getMessage());
                holder.timeText.setText(chatMessage.getTimeSent());
            }

            @Override
            public int getItemCount() {
                return messages.size();
            }

            @Override
            public int getItemViewType(int position) {
                ChatMessage chatMessage = messages.get(position);
                return chatMessage.isSentButton() ? 0 : 1;
            }
        });

        if(messages == null)
        {
            chatModel.messages.setValue(messages = new ArrayList<>());
            Executor thread = Executors.newSingleThreadExecutor();
            thread.execute(() ->
            {
                messages.addAll( mDAO.getAllMessages() );
                runOnUiThread( () -> binding.recycleView.setAdapter( myAdapter ));
            });
        }

        binding.sendBtn.setOnClickListener(click -> {
            String messageText = binding.editText.getText().toString();
            SimpleDateFormat sdf = new SimpleDateFormat("EE, dd-MMM-yy hh-mm a");
            String currentTime = sdf.format(new Date());
            boolean isSentButton = true;

            ChatMessage newMessage = new ChatMessage(messageText, currentTime, isSentButton);
            messages.add(newMessage);
            myAdapter.notifyItemInserted(messages.size() - 1);

            Executor thread = Executors.newSingleThreadExecutor();
            thread.execute(() -> {
                mDAO.insertMessage(newMessage);
            });

            binding.editText.setText("");
        });


        binding.receiveBtn.setOnClickListener(click -> {
            String messageText = binding.editText.getText().toString();
            SimpleDateFormat sdf = new SimpleDateFormat("EE, dd-MMM-yy hh-mm a");
            String currentTime = sdf.format(new Date());
            boolean isSentButton = false;

            ChatMessage newMessage = new ChatMessage(messageText, currentTime, isSentButton);
            messages.add(newMessage);
            myAdapter.notifyItemInserted(messages.size() - 1);

            Executor thread = Executors.newSingleThreadExecutor();
            thread.execute(() -> {
                mDAO.insertMessage(newMessage);
            });

            binding.editText.setText("");
        });
    }

    class MyRowHolder extends RecyclerView.ViewHolder {
        TextView messageText;
        TextView timeText;

        public MyRowHolder(@NonNull View itemView) {
            super(itemView);

            itemView.setOnClickListener(clk ->{
                int position = getAbsoluteAdapterPosition();
                AlertDialog.Builder alertMsg = new AlertDialog.Builder(ChatRoom.this);
                alertMsg.setTitle("Question :");
                alertMsg.setMessage(getString(R.string.delete_message) + messageText.getText());

                alertMsg.setPositiveButton("Yes", (dialog, cl)-> {
                            ChatMessage removedMessage = messages.get(position);

                            Executor thread = Executors.newSingleThreadExecutor();
                            thread.execute(() -> {
                                mDAO.deleteMessage(removedMessage);
                                mDAO.notify();
                                runOnUiThread(() -> {
                                    messages.remove(position);
                                    myAdapter.notifyItemRemoved(position);

                                    Snackbar.make(messageText, "You deleted this message #" + position, Snackbar.LENGTH_LONG)
                                            .setAction("Undo", undoClick -> {
                                                messages.add(position, removedMessage);
                                                myAdapter.notifyItemInserted(position);

                                                Executor reinsertThread = Executors.newSingleThreadExecutor();
                                                reinsertThread.execute(() -> {
                                                    mDAO.insertMessage(removedMessage);
                                                });
                                            })
                                            .show();
                                });
                            });
                        });
                alertMsg.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                alertMsg.create().show();
            });

            messageText = itemView.findViewById(R.id.message);
            timeText = itemView.findViewById(R.id.time);
        }

    }

}



